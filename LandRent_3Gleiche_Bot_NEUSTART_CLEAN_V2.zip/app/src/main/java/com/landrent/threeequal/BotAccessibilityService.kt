package com.landrent.threeequal

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.atomic.AtomicBoolean

/** Only responsible for real screen taps. */
class BotAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: BotAccessibilityService? = null
    }

    private val gestureBusy = AtomicBoolean(false)
    private var lastGestureAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    fun tap(x: Float, y: Float): Boolean {
        val now = SystemClock.uptimeMillis()
        if (now - lastGestureAt < 70L) return false
        if (!gestureBusy.compareAndSet(false, true)) return false

        val safeX = x.coerceIn(1f, resources.displayMetrics.widthPixels - 2f)
        val safeY = y.coerceIn(1f, resources.displayMetrics.heightPixels - 2f)
        val path = Path().apply { moveTo(safeX, safeY) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 40L))
            .build()

        lastGestureAt = now
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                gestureBusy.set(false)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                gestureBusy.set(false)
            }
        }, null)

        if (!accepted) gestureBusy.set(false)
        return accepted
    }

    override fun onDestroy() {
        instance = null
        gestureBusy.set(false)
        super.onDestroy()
    }
}

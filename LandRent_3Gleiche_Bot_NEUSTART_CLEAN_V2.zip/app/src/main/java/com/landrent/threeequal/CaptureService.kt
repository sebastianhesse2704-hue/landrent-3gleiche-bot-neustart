package com.landrent.threeequal

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.widget.Toast

class CaptureService : Service() {
    private val binder = LocalBinder()
    inner class LocalBinder : android.os.Binder() { fun service(): CaptureService = this@CaptureService }
    companion object {
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_DATA = "projection_data"
        @Volatile var running = false
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var botEnabled = false
    private var lastFrameAt = 0L
    private val bot = BotEngine { x, y -> BotAccessibilityService.instance?.tap(x, y) == true }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startAsForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (resultCode != Int.MIN_VALUE && data != null && !running) startProjection(resultCode, data)
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    fun setBotEnabled(enabled: Boolean) {
        botEnabled = enabled && running
        bot.enabled = botEnabled
        Toast.makeText(this, if (botEnabled) "3-Gleiche-Bot läuft" else "3-Gleiche-Bot gestoppt", Toast.LENGTH_SHORT).show()
    }

    fun isBotEnabled(): Boolean = botEnabled

    private fun startProjection(resultCode: Int, data: Intent) {
        try {
            val manager = getSystemService(MediaProjectionManager::class.java)
            val mp = manager.getMediaProjection(resultCode, data)
                ?: throw IllegalStateException("MediaProjection nicht verfügbar")
            projection = mp
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopCapture() }
            }, null)

            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager)
                .defaultDisplay.getRealMetrics(metrics)

            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            reader!!.setOnImageAvailableListener({ ir ->
                val now = android.os.SystemClock.uptimeMillis()
                if (now - lastFrameAt < 100L) {
                    ir.acquireLatestImage()?.close()
                    return@setOnImageAvailableListener
                }
                lastFrameAt = now
                val image = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val plane = image.planes[0]
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * width
                    val bitmapWidth = width + rowPadding / pixelStride
                    val bitmap = Bitmap.createBitmap(bitmapWidth, height, Bitmap.Config.ARGB_8888)
                    bitmap.copyPixelsFromBuffer(plane.buffer)
                    val frame = if (bitmapWidth == width) bitmap else Bitmap.createBitmap(bitmap, 0, 0, width, height)
                    if (frame !== bitmap) bitmap.recycle()
                    try {
                        if (botEnabled) bot.process(frame)
                    } finally {
                        frame.recycle()
                    }
                } catch (_: Throwable) {
                    // A single bad frame must never stop the bot.
                } finally {
                    image.close()
                }
            }, null)

            display = mp.createVirtualDisplay(
                "LandRent3Gleiche",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader!!.surface,
                null,
                null
            )
            running = true
            Toast.makeText(this, "Bildschirmzugriff aktiv ✓", Toast.LENGTH_SHORT).show()
        } catch (e: Throwable) {
            Toast.makeText(this, "Bildschirmzugriff fehlgeschlagen: ${e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            stopCapture()
        }
    }

    private fun stopCapture() {
        running = false
        botEnabled = false
        bot.enabled = false
        val oldDisplay = display
        val oldReader = reader
        val oldProjection = projection
        display = null
        reader = null
        projection = null
        oldDisplay?.release()
        oldReader?.close()
        if (oldProjection != null) {
            try { oldProjection.stop() } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val notification = Notification.Builder(this, "landrent_capture")
            .setContentTitle("LandRent 3 Gleiche")
            .setContentText("Bildschirmzugriff aktiv")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1001, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1001, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                "landrent_capture",
                "LandRent Bot",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}

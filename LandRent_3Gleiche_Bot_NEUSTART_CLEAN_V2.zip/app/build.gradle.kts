plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.landrent.threeequal"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.landrent.threeequal"
        minSdk = 30
        targetSdk = 35
        versionCode = 101
        versionName = "101.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
